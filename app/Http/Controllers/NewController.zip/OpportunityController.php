<?php

namespace App\Http\Controllers;

use App\Client;
use App\Commission;
use App\Opportunity;
use App\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Validator;

class OpportunityController extends Controller
{
    public function __construct()
    {

    }

    private function checkAdmin(){
        //admin=1
        //line_manager=2
        //employee=3
        //applicant=0
        if (Auth::user()->role=='3'){
            return true;
        }
    }

    public function index()
    {
        if ($this->checkAdmin()==false){return $this->redirectHome();}
        $clients=Client::all();
        $opportunities = Opportunity::withCount('commissions')->get();//Trophy Cassava
        return view('commissions.opportunities', compact('opportunities','clients'));
    }

    public function showOpportunity($id)
    {
        if ($this->checkAdmin()==false){return $this->redirectHome();}
        $staffs = User::all();
        $opportunity = Opportunity::findorfail($id);
        $staff_commissions = Commission::where('opportunity_id', $id)->with('user')->get();
        return view('commissions.staffOpportunity', compact('staff_commissions', 'opportunity', 'staffs'));
    }


    public function create()
    {
        //
    }

    public function store(Request $request)
    {
        if ($this->checkAdmin()==false){return $this->redirectHome();}
        //return $request->all();
        Validator::make($request->all(), [
            'client_id' => 'required',
            'project_name' => 'required',
            'project_amount' => 'required',
            'project_status' => 'required',
            'payment_status' => 'required',
            'date' => 'required',
        ])->validate();

        $date=Carbon::createFromFormat('m/d/Y',$request->date)->format('Y-m-d');
        $new = new Opportunity();
        $new->client_id = $request->client_id;
        $new->project_name = $request->project_name;
        $new->project_amount = $request->project_amount;
        $new->project_status = $request->project_status;
        $new->payment_status = $request->payment_status;
        $new->date = $date;
        $new->save();
        return Redirect::back();
    }

    public function storefromExcel(Request $request)
    {
        if ($this->checkAdmin()==false){return $this->redirectHome();}
        Validator::make($request->all(), [
            'client_id' => 'required',
            'project_name' => 'required',
            'date' => 'required',
        ])->validate();

        $new = new Opportunity();
        $new->client_id = $request->client_id;
        $new->project_name = $request->project_name;
        $new->date = $request->date;
        $new->project_status = $request->project_status;
        $new->save();
        return \redirect(route('opportunity.index'));
    }


    public function show($id)
    {
        //
    }


    public function edit($id)
    {
        //
    }


    public function update(Request $request, $id)
    {
        if ($this->checkAdmin()==false){return $this->redirectHome();}
        Validator::make($request->all(), [
            'client_id' => 'required',
            'project_name' => 'required',
            'date' => 'required',
        ])->validate();

        $new = Opportunity::find($id);
        $new->client_id = $request->client_id;
        $new->project_name = $request->project_name;
        $new->date = $request->date;
        $new->project_status = $request->project_status;
        $new->save();
        return \redirect(route('opportunity.index'));
    }

    public function destroy($id)
    {
        //
    }
}
