<?php

namespace App\Http\Controllers;

use App\Commission;
use App\SpecificSalaryComponent;
use App\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Validator;

class CommissionController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    private function checkAdmin(){
        //admin=1
        //line_manager=2
        //employee=3
        //applicant=0
        if (Auth::user()->role=='3'){
            return true;
        }
    }

    private function redirectHome(){
        return \redirect(url('home'));
    }

    public function index()
    {
        if ($this->checkAdmin()==false){return $this->redirectHome();}
        $commissions = Commission::all();
        return view('commissions.commissions', compact('commissions'));
    }

    public function create()
    {
        //
    }

    public function store(Request $request)
    {
        if ($this->checkAdmin()==false){return $this->redirectHome();}
        Validator::make($request->all(), [
            'opportunity_id' => 'required',
            'staff_id' => 'required',
            'commission' => 'required',
        ])->validate();

        $new = new Commission();
        $new->opportunity_id = $request->opportunity_id;
        $new->staff_id = $request->staff_id;
        $new->commission = $request->commission;
        $new->payment_status = 'pending';
        $new->save();
        return Redirect::back();
    }

    public function payCommission($id)
    {
        if ($this->checkAdmin()==false){return $this->redirectHome();}
        Commission::where('id',$id)->update(['payment_status'=>'paid']);

        $staff_commission = Commission::where('id',$id)->with('user')->with('opportunity')->first();

        $new = new SpecificSalaryComponent();
        $new->emp_num = $staff_commission->user->emp_num;
        $new->name = $staff_commission->opportunity->project_name . ' Commission';
        $new->type = '1';
        $new->amount = $staff_commission->commission;
        $new->comment = $staff_commission->opportunity->project_name . ' Commission';;
        $new->duration = '1';
        $new->grants = '0';
        $new->status = '1';
        $new->save();

        return Redirect::back();
    }

    public function myCommission(){
        $user=Auth::user();
        $commissions=Commission::where('staff_id',$user->id)->with('opportunity.client')->get();
        $today=Carbon::today();

        return view('commissions.mycommissions', compact('commissions','user'));
    }
    public function userCommission($id){
        if ($this->checkAdmin()==false){return $this->redirectHome();}
        $user=User::find($id);
        $commissions=Commission::where('staff_id',$user->id)->with('opportunity.client')->get();
        $today=Carbon::today();

        return view('commissions.mycommissions', compact('commissions','user'));

    }

    public function show($id)
    {
        //
    }

    public function edit($id)
    {
        //
    }

    public function update(Request $request, $id)
    {
        if ($this->checkAdmin()==false){return $this->redirectHome();}
        Validator::make($request->all(), [
            'opportunity_id' => 'required',
            'staff_id' => 'required',
            'commission' => 'required',
            'payment_status' => 'required',
        ])->validate();

        $new = Commission::find($id);
        $new->opportunity_id = $request->opportunity_id;
        $new->staff_id = $request->staff_id;
        $new->commission = $request->commission;
        $new->payment_status = $request->payment_status;
        $new->save();
        return \redirect(route('commission.index'));
    }

    public function destroy($id)
    {
        //
    }
}
