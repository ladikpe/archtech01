<?php 

namespace App\AdapterObjects;

use App\Adapters\FetchKpiUserDepartmentAdapter;

class FetchKpiUserDepartmentAdapterObject implements FetchKpiUserDepartmentAdapter{
    
    private $user = null;
    private $kpiDepartment = null;
    private $kpiIntervalId = null;


    function fetch(){
        $response = $this->user->get_kpi_departments;
        // dd($response);
        $result = [];
        foreach ($response as $k => $v) {
          if ($v->kpi_frequency_interval_id == $this->kpiIntervalId->id && $v->group_id == $this->kpiDepartment->id) {
            $result = $v;
          }
        }
        return [
          'data' => $result
        ];  
    } //joy - yts


    // function all($user, $kpiDepartment, $kpiFrequencyIntervalId)
    // {
    //   $response = $user->get_kpi_departments;
    //   // dd($response);
    //   $result = [];
    //   foreach ($response as $k => $v) {
    //     if ($v->kpi_frequency_interval_id == $kpiFrequencyIntervalId->id && $v->group_id == $kpiDepartment->id) {
    //       $result = $v;
    //     }
    //   }
    //   return [
    //     'data' => $result
    //   ];
    // }  

    function setUser($user){
      $this->user = $user;
    }

    function setKpiDepartment($kpiDepartment){
      $this->kpiDepartment = $kpiDepartment;
    }

    function setKpiIntervalId($kpiIntervalId){
      $this->kpiIntervalId = $kpiIntervalId;
    }


}