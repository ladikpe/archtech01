<?php 

namespace App\AdapterObjects;

// use App\Mail\GlobalSend;
use App\Mail\LineManagerSend;
use Illuminate\Support\Facades\Mail;
use App\Adapters\KpiNotifyUserAdapter;

class KpiNotifyLineManagerObject implements KpiNotifyUserAdapter{

    private $request = null;
    private $user = null;

    function getUser(){
      return $this->user;
    }

    function setUser($user){
       $this->user = $user;
    }

    function getRequest(){
      return $this->request;
    }

    function setRequest($request){
      $this->request = $request;
    }

    function sendNotification(){

       $mail = new LineManagerSend;

       $mail->from('info@pali365.com')->subject('KPI Notification FROM YOUR TEAM-MEMBER.');

       Mail::to($this->user->email)->send($mail);
        //send the notification here ... 
        return [
            'message'=>'Notification sent to line-manager',
            'data'=>$this->user
        ];

    }

    
}