<?php

namespace App\AdapterObjects;

use App\User;
use App\Kpi\KpiFrequency;
use App\Adapters\KpiNotifyUserAdapter;
use App\Adapters\RunNotificationAdapter;

class RunNotificationAdapterObject implements RunNotificationAdapter
{

    private $kpiNotifyUserAdapter = null;

    function getProximityValue()
    {
        return 5;
    }

    function isProximityNear()
    {
        $obj = KpiFrequency::getByYear(date('Y'));
        if (!is_null($obj->current_interval)) {
            //interval_upper_bound
            $proxmity = $obj->interval_upper_bound;
            return ($proxmity <= $this->getProximityValue());
            // current_interval
        } else {
            return false;
        }
        //   return $this->getProximityValue() > 0;
    }

    function getUsers()
    {
        $users = User::all();
        return $users;
    }

    function setNotification(KpiNotifyUserAdapter $kpiNotifyUserAdapter)
    {
        $this->kpiNotifyUserAdapter = $kpiNotifyUserAdapter;
    }

    function sendNotification()
    {
        $this->kpiNotifyUserAdapter->sendNotification();
    }
}
