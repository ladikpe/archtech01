<?php

namespace App\AdapterObjects;

use App\Kpi\KpiFrequency;
// use App\Adapters\AddKpiUserDepartmentAdapter;
use App\Adapters\KpiNotifyUserAdapter;
use App\Adapters\AddKpiUserOrganizationAdapter;

class AddKpiUserOrganizationAdapterObject implements AddKpiUserOrganizationAdapter
{

  private $request = null;
  private $user = null;
  private $kpiOrganization = null;
  private $kpiFrequencyIntervalId = null;
  private $kpiUserOrganization = null;

  private $logMessage = '';
  private $kpiNotifyUserAdapter = null;


  protected function isValid()
  {
    $obj = KpiFrequency::getByYear(date('Y'));
    return !is_null($obj->current_interval);
  }

  //setNotification
  function setNotification(KpiNotifyUserAdapter $kpiNotifyUserAdapter)
  {
    $this->kpiNotifyUserAdapter = $kpiNotifyUserAdapter;
  }


  protected function canModify()
  { //kpi_frequency_interval_id
    $obj = KpiFrequency::getByYear(date('Y'));

    if (is_null($obj->current_interval)) {
      return false;
    } else {
      if ($this->request->has('kpi_frequency_interval_id')) {
        if ($obj->current_interval->id == $this->request->kpi_frequency_interval_id) {
          return true;
        } else {
          return false;
        }
      } else {
        return false;
      }
    }
    // return !is_null($obj->current_interval);

  }




  function rateByMe()
  {
    $data = null;
    if ($this->isValid()) {

      if ($this->canModify()) {

        if ($this->hasRating()) {
          $this->updateRatingByMe();
          $this->kpiUserOrganization->save();
          $data = $this->kpiUserOrganization;
        } else {
          $this->updateRatingByMe();
          $this->kpiUserOrganization->save();
          $data = $this->kpiUserOrganization;
        }

        //send notification here....
        // $this->kpiNotifyUserAdapter->sendNotification();

        return [
          'message' => 'Your Rating has been updated...' . $this->logMessage,
          'data' => $data
        ];
      } else {
        return [
          'message' => 'KPI is locked for modification!',
          'data' => null
        ];
      }
    } else {
      return [
        'message' => 'Your KPI window-interval has expired!',
        'data' => $data
      ];
    }
  }

  private function updateRatingByMe()
  {
    // if (!$this->isValid()){
    //   $model->log = 'Late Update...';
    //   $this->logMessage = ' (' . $model->log . ')';
    // }  
    $this->kpiUserOrganization->kpi_frequency_interval_id = $this->kpiFrequencyIntervalId->id;
    $this->kpiUserOrganization->group_id = $this->kpiOrganization->id;
    $this->kpiUserOrganization->user_id = $this->user->id;
    $this->kpiUserOrganization->user_rate = $this->request->user_rate;
    $this->kpiUserOrganization->comments = $this->request->comments;
  }


  function hasRating()
  {
    // if (!is_null($model)){
    $response = $this->all();
    $check = false;
    if (!empty($response['data'])) {
      // foreach ($response['data'] as $k => $v) {
      $v = $response['data'];
      if ($v->kpi_frequency_interval_id == $this->kpiFrequencyIntervalId->id && $v->group_id == $this->kpiOrganization->id) {
        $check = true;
        $this->kpiUserOrganization = $v;
      }
      // }
    } else {
      $check = false;
    }
    // }else{
    //  $check = false;
    // }
    return $check;
  }

  function all()
  {
    $response = $this->user->get_kpi_organizations;
    // dd($response);
    $result = [];
    foreach ($response as $k => $v) {
      if ($v->kpi_frequency_interval_id == $this->kpiFrequencyIntervalId->id && $v->group_id == $this->kpiOrganization->id) {
        $result = $v;
      }
    }
    return [
      'data' => $result
    ];
  } //joy - yts


  //charlie sheen
  //carlos estevez



  function rateByLineManager()
  {

    $data = null;
    if ($this->isValid()) {

      if ($this->canModify()) {

        if ($this->hasRating()) {
          $this->updateRatingByThirdParty();
          $this->kpiUserOrganization->save();
          $data = $this->kpiUserOrganization;
        } else {
          $this->updateRatingByThirdParty();
          $this->kpiUserOrganization->save();
          $data = $this->kpiUserOrganization;
        }

        //send notification here....

        return [
          'message' => 'Your Supervisory Rating has been updated.' . $this->logMessage,
          'data' => $data
        ];
      } else {
        return [
          'message' => 'KPI is locked for modification!',
          'data' => null
        ];
      }
    } else {
      return [
        'message' => 'Your KPI window-interval has expired!',
        'data' => $data
      ];
    }
  }

  private function updateRatingByThirdParty()
  {
    // if (!$this->isValid()){
    //   $model->log = 'Late Update...';
    //   $this->logMessage = ' (' . $model->log . ')';
    // }
    $this->kpiUserOrganization->kpi_frequency_interval_id = $this->kpiFrequencyIntervalId->id;
    $this->kpiUserOrganization->group_id = $this->kpiOrganization->id;
    $this->kpiUserOrganization->user_id = $this->user->id;
    $this->kpiUserOrganization->linemanager_id = $this->user->linemanager_id;
    $this->kpiUserOrganization->linemanager_rate = $this->request->linemanager_rate;
    $this->kpiUserOrganization->linemanager_comments = $this->request->linemanager_comments;
  }


  function setKpiUserOrganization($kpiUserOrganization)
  {
    $this->kpiUserOrganization = $kpiUserOrganization;
  }

  // function setKpiUserOrganisation($kpiUserOrganisation)
  // {
  //   $this->kpiUserOrganisation = $kpiUserOrganisation;
  // }

  function getKpiUserOrganization()
  {
    return $this->kpiUserOrganization;
  }

  //user
  function setUser($user)
  {
    $this->user = $user;
  }

  //micro-verse

  function getUser()
  {
    return $this->user;
  }

  //kpi-department
  function setKpiOrganization($kpiOrganization)
  {
    $this->kpiOrganization = $kpiOrganization;
  }

  function getKpiOrganization()
  {
    return $this->kpiOrganization;
  }

  // function getKpiDepartment(){
  //   return $this->kpiDepartment;
  // }

  //
  function setKpiFrequencyIntervalId($kpiFrequencyIntervalId)
  {
    $this->kpiFrequencyIntervalId = $kpiFrequencyIntervalId;
  }

  function getKpiFrequencyIntervalId()
  {
    return $this->kpiFrequencyIntervalId;
  }

  function setRequest($request)
  {
    $this->request = $request;
  }

  function getRequest()
  {
    return $this->request;
  }
}
