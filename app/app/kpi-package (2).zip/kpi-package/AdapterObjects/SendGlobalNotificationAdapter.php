<?php 
namespace App\AdapterObjects;

use Auth;
use App\User;
use Illuminate\Http\Request;
use App\Adapters\SendGlobalNotificationPort;

class SendGlobalNotificationAdapter implements SendGlobalNotificationPort {

    private $request = null;

    function __construct(Request $request)
    {
        $this->request = $request;
    }

    function getEmailCopy()
    {
        
    }
    // function getEmailTo()
    // {
    //   return Auth::user()->email;   
    // }
    function getSubject()
    {
      return $this->request->subject;   
    }

    function getMessage()
    {
      return $this->request->message;  
    }

    function getUsers()
    {
        $users = User::all();
        return $users;
    }

}