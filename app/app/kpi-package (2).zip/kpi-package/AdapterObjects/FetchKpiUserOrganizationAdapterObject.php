<?php 
namespace App\AdapterObjects;

use App\Adapters\FetchKpiUserOrganizationAdapter;

class FetchKpiUserOrganizationAdapterObject implements FetchKpiUserOrganizationAdapter{
    
    private $kpiIntervalId = null;
    private $user = null;
    private $kpiOrganization = null;
     
    function setKpiIntervalId($kpiIntervalId)
    {
       $this->kpiIntervalId = $kpiIntervalId;  
    } 

    function fetch()
    {
        $response = $this->user->get_kpi_organizations;
        $result = [];
        foreach ($response as $k => $v) {
          if ($v->kpi_frequency_interval_id == $this->kpiIntervalId->id && $v->group_id == $this->kpiOrganization->id) {
            $result = $v;
          }
        }
        return [
          'data' => $result
        ];            
    }

    function setUser($user)
    {
      $this->user = $user;   
    }

    function setKpiOrganization($kpiOrganization)
    {
      $this->kpiOrganization = $kpiOrganization;  
    }

}