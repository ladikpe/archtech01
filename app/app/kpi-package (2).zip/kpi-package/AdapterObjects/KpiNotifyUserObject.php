<?php

namespace App\AdapterObjects;

// namespace App\AdapterObjects;

// use App\Mail\GlobalSend;
// use App\Mail\LineManagerSend;
use App\Mail\KpiProximityUserSend;
use Illuminate\Support\Facades\Mail;
use App\Adapters\KpiNotifyUserAdapter;
use Exception;

class KpiNotifyUserObject implements KpiNotifyUserAdapter
{

    private $request = null;
    private $user = null;

    function getUser()
    {
        return $this->user;
    }

    function setUser($user)
    {
        $this->user = $user;
    }

    function getRequest()
    {
        return $this->request;
    }

    function setRequest($request)
    {
        $this->request = $request;
    }

    private function isValidEmail($email)
    {
        if (empty($email)) {
            $r = explode('@', $email);
            if (count($r) > 1) {
                $r = $r[1];
                $r = explode('.', $r);
                if (count($r) > 1) {
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    function sendNotification()
    {

        $mail = new KpiProximityUserSend;

        $mail->from('info@pali365.com')->subject('Update Your KPI before closure.');

        try {

            if ($this->isValidEmail($this->user->email)) {
                Mail::to($this->user->email)->send($mail);
            }
        } catch (\Exception $ex) { }
        //send the notification here ... 
        return [
            'message' => 'Notification sent to line-manager',
            'data' => $this->user
        ];
    }
}
