<?php
namespace App\AdapterObjects;

use App\Kpi\KpiFrequency;
use App\Adapters\KpiNotifyUserAdapter;
use App\Adapters\AddKpiUserDepartmentAdapter;

class AddKpiUserDepartmentAdapterObject implements AddKpiUserDepartmentAdapter{

    private $request = null;
    private $user = null;
    private $kpiDepartment = null;
    private $kpiFrequencyIntervalId = null;
    private $kpiUserDepartment = null;
    private $logMessage = '';
    private $kpiNotifyUserAdapter = null;


    protected function isValid()
    {
      $obj = KpiFrequency::getByYear(date('Y'));
      return !is_null($obj->current_interval);
    }

    protected function canModify(){ //kpi_frequency_interval_id
        $obj = KpiFrequency::getByYear(date('Y'));
       
        if (is_null($obj->current_interval)){
          return false;
        }else{
          if ($this->request->has('kpi_frequency_interval_id')){
             if ($obj->current_interval->id == $this->request->kpi_frequency_interval_id){
                 return true;
             }else{
                 return false;
             }
          }else{
              return false;
          }
        }
        // return !is_null($obj->current_interval);
    
    }

    // sendNotification
    // function setNotification(KpiNotifyUserAdapter $kpiNotifyUserAdapter);
    function setNotification(KpiNotifyUserAdapter $kpiNotifyUserAdapter)
    {
      $this->kpiNotifyUserAdapter = $kpiNotifyUserAdapter;   
    }




    function rateByMe(){
        $data = null;
        if ($this->isValid()) {
    
          if ($this->canModify()){
    
            if ($this->hasRating()) {
              $this->updateRatingByMe();
              $this->kpiUserDepartment->save();
              $data = $this->kpiUserDepartment;
            } else {
              $this->updateRatingByMe();
              $this->kpiUserDepartment->save();
              $data = $this->kpiUserDepartment;
            }

            // $this->kpiNotifyUserAdapter->sendNotification();
    
            //send notification here....
      
            return [
              'message' => 'Your Rating has been updated...' . $this->logMessage,
              'data' => $data
            ];
      
          }else{
            return [
              'message' => 'KPI is locked for modification!',
              'data' => null
            ];  
          } 
    
        } else {
          return [
            'message' => 'Your KPI window-interval has expired!',
            'data' => $data
          ];
        }    
    }

    private function updateRatingByMe()
    {
      // if (!$this->isValid()){
      //   $model->log = 'Late Update...';
      //   $this->logMessage = ' (' . $model->log . ')';
      // }  
      $this->kpiUserDepartment->kpi_frequency_interval_id = $this->kpiFrequencyIntervalId->id;
      $this->kpiUserDepartment->group_id = $this->kpiDepartment->id;
      $this->kpiUserDepartment->user_id = $this->user->id;
      $this->kpiUserDepartment->user_rate = $this->request->user_rate;
      $this->kpiUserDepartment->comments = $this->request->comments;

    }
  

    function hasRating()
    {
      // if (!is_null($model)){
      $response = $this->all();
      $check = false;
      if (!empty($response['data'])) {
        // foreach ($response['data'] as $k => $v) {
        $v = $response['data'];
        if ($v->kpi_frequency_interval_id == $this->kpiFrequencyIntervalId->id && $v->group_id == $this->kpiDepartment->id) {
          $check = true;
          $this->kpiUserDepartment = $v;
        }
        // }
      } else {
        $check = false;
      }
      // }else{
      //  $check = false;
      // }
      return $check;
    }

    function all()
    {
      $response = $this->user->get_kpi_departments;
      // dd($response);
      $result = [];
      foreach ($response as $k => $v) {
        if ($v->kpi_frequency_interval_id == $this->kpiFrequencyIntervalId->id && $v->group_id == $this->kpiDepartment->id) {
          $result = $v;
        }
      }
      return [
        'data' => $result
      ];
    } //joy - yts


    //charlie sheen
    //carlos estevez
  
  

    function rateByLineManager()
    {
  
      $data = null;
      if ($this->isValid()) {
  
       if ($this->canModify()){
  
        if ($this->hasRating()) {
          $this->updateRatingByThirdParty();
          $this->kpiUserDepartment->save();
          $data = $this->kpiUserDepartment;
        } else {
          $this->updateRatingByThirdParty();
          $this->kpiUserDepartment->save();
          $data = $this->kpiUserDepartment;
        }
  
        //send notification here....
  
        return [
          'message' => 'Your Supervisory Rating has been updated.' . $this->logMessage,
          'data' => $data
        ];
  
       }else{
         return [
           'message' => 'KPI is locked for modification!',
           'data' => null
         ];  
       } 
  
      } else {
        return [
          'message' => 'Your KPI window-interval has expired!',
          'data' => $data
        ];
      }
    }

    private function updateRatingByThirdParty()
    {
      // if (!$this->isValid()){
      //   $model->log = 'Late Update...';
      //   $this->logMessage = ' (' . $model->log . ')';
      // }
      $this->kpiUserDepartment->kpi_frequency_interval_id = $this->kpiFrequencyIntervalId->id;
      $this->kpiUserDepartment->group_id = $this->kpiDepartment->id;
      $this->kpiUserDepartment->user_id = $this->user->id;
      $this->kpiUserDepartment->linemanager_id = $this->user->linemanager_id;
      $this->kpiUserDepartment->linemanager_rate = $this->request->linemanager_rate;
      $this->kpiUserDepartment->linemanager_comments = $this->request->linemanager_comments;
    }
  
  


    function setKpiUserDepartment($kpiUserDepartment){
        $this->kpiUserDepartment = $kpiUserDepartment;

    }

    function getKpiUserDepartment(){
       return $this->kpiUserDepartment;
    }
    
    //user
    function setUser($user){
      $this->user = $user;
    }

    //micro-verse

    function getUser(){
     return $this->user;
    }

    //kpi-department
    function setKpiDepartment($kpiDepartment){
      $this->kpiDepartment = $kpiDepartment;
    }

    function getKpiDepartment(){
      return $this->kpiDepartment;
    }

    //
    function setKpiFrequencyIntervalId($kpiFrequencyIntervalId){
      $this->kpiFrequencyIntervalId = $kpiFrequencyIntervalId;
    }

    function getKpiFrequencyIntervalId(){
      return $this->kpiFrequencyIntervalId;
    }

    function setRequest($request){
      $this->request = $request;
    }

    function getRequest(){
       return $this->request;
    }


}