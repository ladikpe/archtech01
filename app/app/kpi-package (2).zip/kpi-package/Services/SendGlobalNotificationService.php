<?php 
namespace App\Services;

// use Illuminate\Support\Facades\Mail;
use App\Adapters\SendGlobalNotificationPort;
use Mail;


class SendGlobalNotificationService implements SendGlobalNotificationPort{
  
      private $sendGlobalNotificationPort = null;

      function __construct(SendGlobalNotificationPort $sendGlobalNotificationPort)
      {
          $this->sendGlobalNotificationPort = $sendGlobalNotificationPort;
      } 

      function send()
      {
          $ref = $this;
          $data = [];
          $data['message'] = $this->getMessage();
          $data['subject'] = $this->getSubject();
          $response = Mail::send('mails.default', $data, function ($message) use ($ref) {
              
              $message->from('alex@snapnet.com.ng', 'Alex');
              $message->sender('alex@snapnet.com.ng', 'Alex');
              $message->to('alex@snapnet.com.ng', 'Alex');
            //   $message->cc('john@johndoe.com', 'John Doe');
            //   $message->bcc('john@johndoe.com', 'John Doe');
            //   $message->replyTo('john@johndoe.com', 'John Doe');
              $message->subject($ref->getSubject());
              $message->priority(3);
            //   $message->attach('pathToFile');

          });

          $users = $this->getUsers();

          foreach ($users as $k=>$user){
              //
          }

          return [
              'message'=>'Kpi Notification Reminder sent.',
              'data'=>$response
          ];

        //   return $this->sendGlobalNotificationPort->send();
      }

      function getEmailCopy()
      {
          return $this->sendGlobalNotificationPort->getEmailCopy();
      }

    //   function getEmailTo()
    //   {
    //       return $this->sendGlobalNotificationPort->getEmailTo();
    //   }

      function getSubject()
      {
          return $this->sendGlobalNotificationPort->getSubject();
      }

      function getMessage()
      {
          return $this->sendGlobalNotificationPort->getMessage();
      }

      function getUsers(){
          return $this->sendGlobalNotificationPort->getUsers();
      }

}