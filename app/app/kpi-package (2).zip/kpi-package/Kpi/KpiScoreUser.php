<?php 

namespace App\Kpi;

use App\Kpi\KpiUserDepartment;
use App\Kpi\KpiUserOrganization;


class KpiScoreUser{

  
      
    function getScore($config=[]){ //$field,$user_id,$kpi_frequency_interval_id,
      
      $field = $config['field'];
      $user_id = $config['user_id'];
      $kpi_frequency_interval_id = $config['kpi_frequency_interval_id'];

      $tot = 0;

      $totDep = 0;
      $totOrg = 0;
      
      $all = KpiUserDepartment::where('kpi_frequency_interval_id',$kpi_frequency_interval_id)
                                ->where('user_id',$user_id)->get();
      
      foreach ($all as $k=>$v){
         if (is_numeric($v->$field)){
           $tot+=$v->$field;
         }
      }
      $totDep = $tot;

      $all = KpiUserOrganization::where('kpi_frequency_interval_id',$kpi_frequency_interval_id)
                                  ->where('user_id',$user_id)->get();
      
      foreach ($all as $k=>$v){
         if (is_numeric($v->$field)){
           $tot+=$v->$field;
           $totOrg+=$v->$field;
         }
      }


      return [
          'score'=>number_format($tot/20,2),
          'departmentTotal'=>$totDep,
          'organizationTotal'=>$totOrg,
          'sumTotal'=>$tot,
          'dividingFactor'=>20
      ];
       

    }


}