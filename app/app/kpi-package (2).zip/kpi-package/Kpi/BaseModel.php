<?php

namespace App\Kpi;

use Illuminate\Database\Eloquent\Model;

class BaseModel extends Model
{
    
    

    function whereHass($relation,$fn){
        return $fn($this->$relation());
        // return $this;
    }

    // function  kpi_frequency_intervals(){
    //     return $this->hasMany(KpiFrequencyInterval::class,'kpi_frequency_id');
    // }

    // function getCurrentInterval($config=[]){ // year , month , day
    //   //y-m-d 
    // //   $year = $config['year'];
    // //   $month = $config['month'];
    // //   $day = $config['day'];

    //   $date = $config['date'];
      
    //   $list = $this->kpi_frequency_intervals()->where('date_start','<=',$date)
    //   ->where('date_stop','>=',$date)->first();

    //   return $list;
    
    // }
    
}
