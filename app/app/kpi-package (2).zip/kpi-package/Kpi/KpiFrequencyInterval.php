<?php

namespace App\Kpi;

use Illuminate\Database\Eloquent\Model;

class KpiFrequencyInterval extends Model
{
    //
    protected $table = 'kpi_frequency_intervals';

    function kpi_frequency()
    {
        return $this->belongsTo(KpiFrequency::class, 'kpi_frequency_id');
    }
}
