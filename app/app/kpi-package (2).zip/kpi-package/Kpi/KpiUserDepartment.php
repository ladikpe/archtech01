<?php

namespace App\Kpi;

use Illuminate\Database\Eloquent\Model;

use App\Kpi\KpiDepartment;

use App\User;

class KpiUserDepartment extends Model
{
    //
    protected $table = 'kpi_user_departments';

    function kpiDepartment(){
        return $this->belongsTo(KpiDepartment::class,'group_id');
    }

    function user(){
        return $this->belongsTo(User::class,'user_id');
    }

}
