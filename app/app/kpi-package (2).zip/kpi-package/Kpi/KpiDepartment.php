<?php

namespace App\Kpi;

use Illuminate\Database\Eloquent\Model;

use App\JobDep;
// use App\User;
use App\Kpi\KpiUserDepartment;


class KpiDepartment extends Model
{
  //
  protected $table = 'kpi_departments';

  function department()
  {
    return $this->belongsTo(JobDep::class, 'dept_id');
  }

  function groupUsers()
  {
    return $this->hasMany(KpiUserDepartment::class, 'group_id');
  }

  function kpi_frequency()
  {
    return $this->belongsTo(KpiFrequency::class, 'kpi_frequency_id');
  }
}
