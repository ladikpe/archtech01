<?php

namespace App\Kpi;

use Illuminate\Database\Eloquent\Model;

use App\JobDep;

use App\Kpi\KpiUserOrganization;

class KpiOrganization extends Model
{
    //
    protected $table = 'kpi_organizations';


    function department()
    {
        return $this->belongsTo(JobDep::class, 'dept_id');
    }

    function groupUsers()
    {
        return $this->hasMany(KpiUserOrganization::class, 'group_id');
    }

    function kpi_frequency()
    {
        return $this->belongsTo(KpiFrequency::class, 'kpi_frequency_id');
    }
}
