<?php

namespace App\Kpi;

use Illuminate\Database\Eloquent\Model;

use App\Kpi\kpiOrganization;

use App\User;

class KpiUserOrganization extends Model
{
    //
    protected $table = 'kpi_user_organizations';

    

     
    function kpiOrganization(){
        return $this->belongsTo(KpiOrganization::class,'group_id');
    }

    function user(){
       return $this->belongsTo(User::class,'user_id');
    }  

}
