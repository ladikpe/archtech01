<?php

namespace App\Kpi;

use Carbon\Carbon;
use App\Kpi\BaseModel;
use Illuminate\Database\Eloquent\Model;

class KpiFrequency extends BaseModel
{

    protected $table = 'kpi_frequency';

    function  kpi_frequency_intervals(){
        return $this->hasMany(KpiFrequencyInterval::class,'kpi_frequency_id')->with('kpi_frequency');
    }

    function getCurrentInterval($config=[]){ // year , month , day
      //y-m-d 
    //   $year = $config['year'];
    //   $month = $config['month'];
    //   $day = $config['day'];

    $date = $config['date']; 
    // echo '....';
  
    // echo $this->whereHass('kpi_frequency_intervals',function($query) use ($date){        
    //     return $query->where('date_start','<=',$date)->where('date_stop','>=',$date);
    // })->toSql();
    $list = $this->whereHass('kpi_frequency_intervals',function($query) use ($date){
          
        return $query->where('date_start','<=',$date)->where('date_stop','>=',$date);

    })->first();
      
    //   $list = $this->kpi_frequency_intervals()->where('date_start','<=',$date)
    //   ->where('date_stop','>=',$date)->first();

      return $list;
    
    }

    public static function getByYear($year){
        

      
       $obj = self::where('year',$year)->first();
       if (!is_null($obj)){
         $obj->current_interval = $obj->getCurrentInterval([
             'date'=>$year . '-' . date('m-d')
         ]);
         $obj->interval_lower_bound = 0;
         $obj->interval_upper_bound = 0;

         if (!is_null($obj->current_interval)){

           $dateLowerBound = new Carbon($obj->current_interval->date_start);
           $dateUpperBound = new Carbon($obj->current_interval->date_stop);
 
           $lbv = $dateLowerBound->diffInDays(new Carbon); 
           $ubv = $dateUpperBound->diffInDays(new Carbon);
           
           $obj->interval_lower_bound = $lbv;
           $obj->interval_upper_bound = $ubv;

         }else{

         }
  

       }else{
           $obj->current_interval = null;
       }
       return $obj;
    }
    
}
