<?php 

namespace App\Actions\Notifications;

use App\Adapters\KpiNotifyUserAdapter;


class MailToLineManagerAction{
     
    function send(KpiNotifyUserAdapter $kpiNotifyUserAdapter){
        return $kpiNotifyUserAdapter->sendNotification();   
    }

}