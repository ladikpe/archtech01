<?php

namespace App\Actions;

class CrudAction{     

     function store($options=[]){ //$request,$model,$inputString
        $request = $options['request'];
        $model = $options['model'];
        $inputString = $options['inputString'];

        $data = $this->decodeInput([
            'inputString'=>$inputString,
            'request'=>$request,
            'model'=>$model
        ]);

        $model->save();
        
        return $model;

     }

     function update($options=[]){
        $request = $options['request'];
        $model = $options['model'];
        $inputString = $options['inputString'];

        $data = $this->decodeInput([
            'inputString'=>$inputString,
            'request'=>$request,
            'model'=>$model
        ]);

        $model->save();

        return $model;


     }

     function delete($options=[]){ //$request,$model,$inputString
        // $request = $options['request'];
        $model = $options['model'];
        // $inputString = $options['inputString'];

        $model->delete();

        return $model;

     }

     function all($options=[]){ //$model
        $model = $options['model'];
        return $model->all();
     }

     private function decodeInput($options=[]){ //$request,$inputString
        
        $inputString = $options['inputString'];
        $request = $options['request'];
        $model = $options['model'];

        $r = explode(',',$inputString);
        $data = [];
        foreach ($r as $k=>$v){
          $rr = explode('=',$v);
          if (count($rr) > 1){
            $key = $rr[0];
            $value = $rr[1];
            $request->$key = $request->$value;
            $data[$key] = $request->$key;
          }else{
            $key = $v;
            $data[$key] = $request->$key;
          }
        }

        foreach ($data as $k=>$v){
          $model->$k = $v; //update model here ... 
        }

        return $data;

     }


}