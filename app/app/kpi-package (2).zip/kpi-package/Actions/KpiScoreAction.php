<?php 

namespace App\Actions;

use App\Kpi\KpiScoreUser;

class KpiScoreAction{

  
  
     function getScore($config){
        $score = (new KpiScoreUser)->getScore([
             'field'=>$config['field'],
             'user_id'=>$config['user_id'],
             'kpi_frequency_interval_id'=>$config['kpi_frequency_interval_id']
        ]);
        return [
            'message'=>'User score computed successfully.',
            'data'=>$score
        ];
     }
     



}