<?php 

namespace App\Actions;

use App\Kpi\KpiFrequency;


class KpiUserBase{



    protected function canModify($request){ //kpi_frequency_interval_id
        $obj = KpiFrequency::getByYear(date('Y'));
       
        if (is_null($obj->current_interval)){
          return false;
        }else{
          if ($request->has('kpi_frequency_interval_id')){
             if ($obj->current_interval->id == $request->kpi_frequency_interval_id){
                 return true;
             }else{
                 return false;
             }
          }else{
              return false;
          }
        }
        // return !is_null($obj->current_interval);
    
    }


    protected function isValid()
    {
      $obj = KpiFrequency::getByYear(date('Y'));
      return !is_null($obj->current_interval);
    }
  

}