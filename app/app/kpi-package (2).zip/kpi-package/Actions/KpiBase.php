<?php

namespace App\Actions;

class KpiBase
{

    // const MAX = 80;

    private $total = 0;

    protected $MAX = 100;

    protected function isMaxedOut($request, $model, $dept_id, $kpi_frequency_id, $action = 'store', $obj = null)
    {
        $r = false;
        $response = $this->all($model, $dept_id, $kpi_frequency_id);
        $list = $response['data'];
        $tot = 0;
        foreach ($list as $k => $v) {
            $tot += $v->percentage;
        }

        $check = +$request->percentage;
        if ($action == 'store') {
            if (($tot + $check) <= $this->MAX) {
                $r = false;
            } else {
                $r = true;
            }
            $this->total = $tot;
        } else {
            if (($tot + $check - $obj->percentage) <= $this->MAX) {
                $r = false;
            } else {
                $r = true;
            }
            $this->total = $tot;
        }


        return $r;
    }

    protected function getTotalPercentage()
    {
        return $this->total;
    }
}
