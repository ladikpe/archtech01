<?php

namespace App\Actions;

use App\Actions\KpiUserBase;
use App\Adapters\AddKpiUserOrganizationAdapter;
use App\Adapters\FetchKpiUserOrganizationAdapter;

class KpiUserOrganizationAction extends KpiUserBase
{

  private $currentModel = null;


  function fetch(FetchKpiUserOrganizationAdapter $fetchKpiUserOrganizationAdapter)
  {
    return $fetchKpiUserOrganizationAdapter->fetch();
  }


  // function all($user, $kpiOrganization, $kpiFrequencyIntervalId)
  // {
  //   $response = $user->get_kpi_organizations;
  //   $result = [];
  //   foreach ($response as $k => $v) {
  //     if ($v->kpi_frequency_interval_id == $kpiFrequencyIntervalId->id && $v->group_id == $kpiOrganization->id) {
  //       $result = $v;
  //     }
  //   }
  //   return [
  //     'data' => $result
  //   ];
  // } //joy - yts


  function rateByMe(AddKpiUserOrganizationAdapter $addKpiUserOrganizationAdapter)
  {
    return $addKpiUserOrganizationAdapter->rateByMe();
  }


  // function rateByMe($model, $user, $kpiOrganization, $kpiFrequencyIntervalId, $request)
  // {

  //   $data = null;
  //   if ($this->isValid()) {

  //     if ($this->canModify($request)) {

  //       if ($this->hasRating($user, $kpiOrganization, $kpiFrequencyIntervalId)) {
  //         $this->updateRatingByMe($this->currentModel, $user, $kpiOrganization, $kpiFrequencyIntervalId, $request);
  //         $this->currentModel->save();
  //         $data = $this->currentModel;
  //       } else {
  //         $this->updateRatingByMe($model, $user, $kpiOrganization, $kpiFrequencyIntervalId, $request);
  //         $model->save();
  //         $data = $model;
  //       }

  //       return [
  //         'message' => 'Your Rating has been updated...',
  //         'data' => $data
  //       ];
  //     } else {
  //       return [
  //         'message' => 'KPI is locked for modification!',
  //         'data' => null
  //       ];
  //     }
  //   } else {
  //     return [
  //       'message' => 'Your KPI window-interval has expired!',
  //       'data' => $data
  //     ];
  //   }
  // }

  function rateByLineManager(AddKpiUserOrganizationAdapter $addKpiUserOrganizationAdapter)
  {
    return $addKpiUserOrganizationAdapter->rateByLineManager();
  }


  // function rateByLineManager($model, $user, $kpiOrganization, $kpiFrequencyIntervalId, $request)
  // {
  //   $data = null;
  //   if ($this->isValid()) {
  //     if ($this->canModify($request)) {
  //       if ($this->hasRating($user, $kpiOrganization, $kpiFrequencyIntervalId)) {
  //         $this->updateRatingByThirdParty($this->currentModel, $user, $kpiOrganization, $kpiFrequencyIntervalId, $request);
  //         $this->currentModel->save();
  //         $data = $this->currentModel;
  //       } else {
  //         $this->updateRatingByThirdParty($model, $user, $kpiOrganization, $kpiFrequencyIntervalId, $request);
  //         $model->save();
  //         $data = $model;
  //       }

  //       return [
  //         'message' => 'Your Supervisory Rating has been updated.',
  //         'data' => $data
  //       ];    
  //     }else{
  //       return [
  //         'message' => 'KPI is locked for modification!',
  //         'data' => null
  //       ];
  //     } 

  //   }else{
  //     return [
  //       'message' => 'Your KPI window-interval has expired!',
  //       'data' => $data
  //     ];
  //   }

  // }


  // private function updateRatingByThirdParty($model, $user, $kpiOrganization, $kpiFrequencyIntervalId, $request)
  // {
  //   $model->kpi_frequency_interval_id = $kpiFrequencyIntervalId->id;
  //   $model->group_id = $kpiOrganization->id;
  //   $model->user_id = $user->id;
  //   $model->linemanager_id = $user->linemanager_id;
  //   $model->linemanager_rate = $request->linemanager_rate;
  //   $model->linemanager_comments = $request->linemanager_comments;
  // }

  // private function updateRatingByMe($model, $user, $kpiOrganization, $kpiFrequencyIntervalId, $request)
  // {
  //   $model->kpi_frequency_interval_id = $kpiFrequencyIntervalId->id;
  //   $model->group_id = $kpiOrganization->id;
  //   $model->user_id = $user->id;
  //   $model->user_rate = $request->user_rate;
  //   $model->comments = $request->comments;
  // }

  // function hasRating($user, $kpiOrganization, $kpiFrequencyIntervalId)
  // {
  //   // if (!is_null($model)){
  //   $response = $this->all($user, $kpiOrganization, $kpiFrequencyIntervalId);
  //   $check = false;
  //   if (!empty($response['data'])) {
  //     // foreach ($response['data'] as $k => $v) {
  //     $v = $response['data'];
  //     if ($v->kpi_frequency_interval_id == $kpiFrequencyIntervalId->id) {
  //       $check = true;
  //       $this->currentModel = $v;
  //     }
  //     // }
  //   } else {
  //     $check = false;
  //   }
  //   // }else{
  //   //  $check = false;
  //   // }
  //   return $check;
  // }

  // function 

  function getUserValue($config = [])
  {
    $kpiFrequencyIntervalId = $config['kpiFrequencyIntervalId'];
    $group_id = $config['group_id'];
    $user_id = $config['user_id'];
    $kpiUserOrganization = $config['kpiUserOrganization'];

    $result = $kpiUserOrganization->where('kpi_frequency_interval_id', $kpiFrequencyIntervalId)
      ->where('group_id', $group_id)
      ->where('user_id', $user_id)->first();
    return [
      'data' => $result
    ];
  }
}
