<?php

namespace App\Actions;

use App\Actions\ApiResponseAction;

class KpiFrequencyAction extends ApiResponseAction
{



    function store($options = [])
    { //$crudAction,$request,$model
        $crudAction = $options['crudAction'];
        $request = $options['request'];
        $model = $options['model'];

        $data = $crudAction->store([
            'request' => $request,
            'model' => $model,
            'inputString' => 'description,user_id,frequency,year'
        ]);

        return $this->withSuccess('Kpi-Frequency Added', $data);
    }

    function update($options = [])
    {
        $crudAction = $options['crudAction'];
        $request = $options['request'];
        $model = $options['model'];

        $data = $crudAction->store([
            'request' => $request,
            'model' => $model,
            'inputString' => 'description,user_id,frequency,year'
        ]);

        return $this->withSuccess('Kpi-Frequency updated', $data);
    }

    function delete($options = [])
    {
        $crudAction = $options['crudAction'];
        $model = $options['model'];
        $data = $crudAction->delete([
            'model' => $model
        ]);
        return $this->withSuccess('Kpi-Frequency removed', $data);
    }

    function all($options = [])
    {
        $crudAction = $options['crudAction'];
        $model = $options['model'];

        $data = $crudAction->all([
            'model' => $model
        ]);

        return $this->withSuccess('', $data);
    }

    function getCurrentKpiFrequency($options = [])
    { //model,year
        $model = $options['model'];
        $year = $options['year'];
        $data = $model->where('year', $year)->first();
        return $this->withSuccess('', $data);
    }

    function getCurrentInterval($options=[]){
        
        $model = $options['model'];
        $date = $options['date'];

        $data = $model->getCurrentInterval([
            'date'=>$date
        ]);

        return $this->withSuccess('',$data);

    }

    function getByYear($options=[]){
      $model = $options['model'];
      $year = $options['year'];
      return $this->withSuccess('',$model->getByYear($year));
    }


}
