<?php 

namespace App\Actions;

class UserAction{

     
     function all($model,$workdept_id=''){
        if (!empty($workdept_id)){
          $model = $model->where('workdept_id',$workdept_id);
        }
        return [
            'data'=>$model->get()
        ];
     }



}