<?php 

namespace App\Actions;

class ApiResponseAction{


    private $response = [];

    function withError($message,$data){
        $this->response['message'] = $message;
        $this->response['data'] = $data;
        $this->response['error'] = true;
        return $this->response;  
    }

    function withSuccess($message,$data){
      $this->response['message'] = $message;
      $this->response['data'] = $data;
      $this->response['error'] = false;
      return $this->response;
    }



}