<?php

namespace App\Actions;

use App\Actions\ApiResponseAction;

class KpiFrequencyIntervalAction extends ApiResponseAction
{



    function store($options = [])
    { //$crudAction,$request,$model
        $crudAction = $options['crudAction'];
        $request = $options['request'];
        $model = $options['model'];

        $data = $crudAction->store([
            'request' => $request,
            'model' => $model,
            'inputString' => 'kpi_frequency_id,date_start,date_stop,name'
        ]);

        return $this->withSuccess('Kpi-Frequency-Interval Added', $data);
    }

    function update($options = [])
    {
        $crudAction = $options['crudAction'];
        $request = $options['request'];
        $model = $options['model'];

        $data = $crudAction->store([
            'request' => $request,
            'model' => $model,
            'inputString' => 'kpi_frequency_id,date_start,date_stop,name'
        ]);

        return $this->withSuccess('Kpi-Frequency-Interval Updated', $data);
    }

    function delete($options = [])
    {
        $crudAction = $options['crudAction'];
        $model = $options['model'];
        $data = $crudAction->delete([
            'model' => $model
        ]);
        return $this->withSuccess('Kpi-Frequency-interval removed', $data);
    }

    function all($options = [])
    {
        // $crudAction = $options['crudAction'];
        // $model = $options['model'];
        $kpiFrequency = $options['kpiFrequency'];
        // $data = $crudAction->all([
        //     'model' => $model
        // ]);
        $data = $kpiFrequency->kpi_frequency_intervals;
        return $this->withSuccess('', $data);
    }


    // function getCurrentKpiFrequency($options = [])
    // { //model,year
    //     $model = $options['model'];
    //     $year = $options['year'];
    //     $data = $model->where('year', $year)->first();
    //     return $this->withSuccess('', $data);
    // }
    

}
