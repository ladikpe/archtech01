<?php

namespace App\Actions;

// use Illuminate\Database\Query\Builder;
use App\Actions\KpiBase;
use Illuminate\Database\Eloquent\Builder;

class KpiOrganizationAction extends KpiBase
{

    protected $MAX = 20;

    function all($model, $dept_id, $kpi_frequency_id,$kpiUserOrganization='',$kpiUserOrganizationAction='',$request='')
    {
        $result = $model->where('dept_id', $dept_id)
            ->where('kpi_frequency_id', $kpi_frequency_id)
            ->with('groupUsers', 'groupUsers.user')->get();


        $list = $result;

        //&& $request->filled('group_id') 
       if (!empty($request)){
        if ($request->has('kpiFrequencyIntervalId')
            && $request->has('user_id')){
            
                foreach ($list as $k=>$v){
                    $list[$k]['user_selection'] = $kpiUserOrganizationAction->getUserValue([
                    'kpiFrequencyIntervalId'=>$request->kpiFrequencyIntervalId,
                    'group_id'=>$v->id,
                    'user_id'=>$request->user_id,
                    'kpiUserOrganization'=>$kpiUserOrganization
                    ]);     
                }
        }
       } 
      


        return [
            'data' => $result,
            'filter' => $kpi_frequency_id
        ];
    }



    private function getInputs($model, $request)
    {
        $model->dept_id = $request->dept_id;
        $model->content = $request->content;
        $model->kpi_frequency_id = $request->kpi_frequency_id;
        $model->percentage = $request->percentage;
        //    $model->linemager_id
        // $model->year = $request->year;
    }

    function store($model, $request)
    {
        if ($this->isMaxedOut($request, $model, $request->dept_id, $request->kpi_frequency_id)) {
            return [
                'message' => 'Gross percentage maxed out (' . $request->percentage . '% / ' . $this->getTotalPercentage()  . '% )',
                'error' => true
            ];
        } else {
            $this->getInputs($model, $request);
            // if ($model->year == date('Y')) {
                $model->save();
                return [
                    'message' => 'KPI - Organization Created',
                    'data' => $model
                ];
            // } else {
            //     return [
            //         'message' => 'Cannot add KPI, not of this year.',
            //         'data' => null
            //     ];
            // }
        }
    }

    function update($model, $request)
    {
        if ($this->isMaxedOut($request, $model, $request->dept_id, $request->kpi_frequency_id, 'update', $model)) {
            return [
                'message' => 'Gross percentage maxed out (' . $request->percentage . '% / ' . $this->getTotalPercentage()  . '% )',
                'error' => true
            ];
        } else {
            $this->getInputs($model, $request);
            // if ($model->year == date('Y')) {
                $model->save();
                return [
                    'message' => 'KPI - Organization  Updated',
                    'data' => $model
                ];
            // } else {
            //     return [
            //         'message' => 'Cannot update a KPI, not of this year.',
            //         'data' => null
            //     ];
            // }
        }
    }

    function delete($model)
    {
        if ($model->year == date('Y')) {
            $model->delete();
            return [
                'message' => 'KPI - Organization Removed.'
            ];
        } else {
            return [
                'message' => 'Cannot remove this KPI (The year is earlier than this year)!',
                'data' => null
            ];
        }
    }
}
