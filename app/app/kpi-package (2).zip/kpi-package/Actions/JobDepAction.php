<?php 
namespace App\Actions;

class JobDepAction{

  

     function all($model){
         return [
             'data'=>$model->get()
         ]; 
     }



}