<?php

namespace App\Actions;


use App\Kpi\KpiFrequency;
use App\Actions\KpiUserBase;
use App\Adapters\AddKpiUserDepartmentAdapter;
use App\Adapters\FetchKpiUserDepartmentAdapter;

class KpiUserDepartmentAction extends KpiUserBase
{

  private $currentModel = null;
  private $logMessage = '';

  function fetch(FetchKpiUserDepartmentAdapter $fetchKpiUserDepartmentAdapter){
    return $fetchKpiUserDepartmentAdapter->fetch();
  }


  function all($user, $kpiDepartment, $kpiFrequencyIntervalId)
  {
    $response = $user->get_kpi_departments;
    // dd($response);
    $result = [];
    foreach ($response as $k => $v) {
      if ($v->kpi_frequency_interval_id == $kpiFrequencyIntervalId->id && $v->group_id == $kpiDepartment->id) {
        $result = $v;
      }
    }
    return [
      'data' => $result
    ];
  } //joy - yts


  function rateByMe(AddKpiUserDepartmentAdapter $addKpiUserDepartmentAdapter){
     return $addKpiUserDepartmentAdapter->rateByMe();
  }


  // function rateByMe($model, $user, $kpiDepartment, $kpiFrequencyIntervalId, $request)
  // {
  //   $data = null;
  //   if ($this->isValid()) {

  //     if ($this->canModify($request)){

  //       if ($this->hasRating($user, $kpiDepartment, $kpiFrequencyIntervalId)) {
  //         $this->updateRatingByMe($this->currentModel, $user, $kpiDepartment, $kpiFrequencyIntervalId, $request);
  //         $this->currentModel->save();
  //         $data = $this->currentModel;
  //       } else {
  //         $this->updateRatingByMe($model, $user, $kpiDepartment, $kpiFrequencyIntervalId, $request);
  //         $model->save();
  //         $data = $model;
  //       }

  //       //send notification here....
  
  //       return [
  //         'message' => 'Your Rating has been updated...' . $this->logMessage,
  //         'data' => $data
  //       ];
  
  //     }else{
  //       return [
  //         'message' => 'KPI is locked for modification!',
  //         'data' => null
  //       ];  
  //     } 

  //   } else {
  //     return [
  //       'message' => 'Your KPI window-interval has expired!',
  //       'data' => $data
  //     ];
  //   }
  // }


  // private function isValid()
  // {
  //   $obj = KpiFrequency::getByYear(date('Y'));
  //   return !is_null($obj->current_interval);
  // }


  function rateByLineManager(AddKpiUserDepartmentAdapter $addKpiUserDepartmentAdapter){
    return $addKpiUserDepartmentAdapter->rateByLineManager();
  } 

  // function rateByLineManager($model, $user, $kpiDepartment, $kpiFrequencyIntervalId, $request)
  // {

  //   $data = null;
  //   if ($this->isValid()) {

  //    if ($this->canModify($request)){

  //     if ($this->hasRating($user, $kpiDepartment, $kpiFrequencyIntervalId)) {
  //       $this->updateRatingByThirdParty($this->currentModel, $user, $kpiDepartment, $kpiFrequencyIntervalId, $request);
  //       $this->currentModel->save();
  //       $data = $this->currentModel;
  //     } else {
  //       $this->updateRatingByThirdParty($model, $user, $kpiDepartment, $kpiFrequencyIntervalId, $request);
  //       $model->save();
  //       $data = $model;
  //     }

  //     //send notification here....

  //     return [
  //       'message' => 'Your Supervisory Rating has been updated.' . $this->logMessage,
  //       'data' => $data
  //     ];

  //    }else{
  //      return [
  //        'message' => 'KPI is locked for modification!',
  //        'data' => null
  //      ];  
  //    } 

  //   } else {
  //     return [
  //       'message' => 'Your KPI window-interval has expired!',
  //       'data' => $data
  //     ];
  //   }
  // }


  private function updateRatingByThirdParty($model, $user, $kpiDepartment, $kpiFrequencyIntervalId, $request)
  {
    // if (!$this->isValid()){
    //   $model->log = 'Late Update...';
    //   $this->logMessage = ' (' . $model->log . ')';
    // }
    $model->kpi_frequency_interval_id = $kpiFrequencyIntervalId->id;
    $model->group_id = $kpiDepartment->id;
    $model->user_id = $user->id;
    $model->linemanager_id = $user->linemanager_id;
    $model->linemanager_rate = $request->linemanager_rate;
    $model->linemanager_comments = $request->linemanager_comments;
  }



  private function updateRatingByMe($model, $user, $kpiDepartment, $kpiFrequencyIntervalId, $request)
  {
    // if (!$this->isValid()){
    //   $model->log = 'Late Update...';
    //   $this->logMessage = ' (' . $model->log . ')';
    // }  
    $model->kpi_frequency_interval_id = $kpiFrequencyIntervalId->id;
    $model->group_id = $kpiDepartment->id;
    $model->user_id = $user->id;
    $model->user_rate = $request->user_rate;
    $model->comments = $request->comments;
  }

  function hasRating($user, $kpiDepartment, $kpiFrequencyIntervalId)
  {
    // if (!is_null($model)){
    $response = $this->all($user, $kpiDepartment, $kpiFrequencyIntervalId);
    $check = false;
    if (!empty($response['data'])) {
      // foreach ($response['data'] as $k => $v) {
      $v = $response['data'];
      if ($v->kpi_frequency_interval_id == $kpiFrequencyIntervalId->id && $v->group_id == $kpiDepartment->id) {
        $check = true;
        $this->currentModel = $v;
      }
      // }
    } else {
      $check = false;
    }
    // }else{
    //  $check = false;
    // }
    return $check;
  }


  function getUserValue($config=[]){
    $kpiFrequencyIntervalId = $config['kpiFrequencyIntervalId'];
    $group_id = $config['group_id'];
    $user_id = $config['user_id'];
    $kpiUserDepartment = $config['kpiUserDepartment'];

    $result = $kpiUserDepartment->where('kpi_frequency_interval_id',$kpiFrequencyIntervalId)
                                   ->where('group_id',$group_id)
                                   ->where('user_id',$user_id)->first();
    return [
        'data'=>$result
    ];

  }

  // function 

}
