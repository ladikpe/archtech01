<?php 
namespace App\Actions;

use App\Kpi\KpiFrequency;
use App\Adapters\KpiNotifyUserAdapter;
use App\Adapters\RunNotificationAdapter;

class RunNotificationAction{
  
     
     
      function run(RunNotificationAdapter $runNotificationAdapter,KpiNotifyUserAdapter $kpiNotifyUserAdapter){
          //KpiNotifyUserAdapter
        //   return [];
          $usr = [];
           if ($runNotificationAdapter->isProximityNear()){
              $users = $runNotificationAdapter->getUsers();
              $usr = $users;
              foreach ($users as $user){
                 $kpiNotifyUserAdapter->setUser($user); 
                 $runNotificationAdapter->setNotification($kpiNotifyUserAdapter);
                 $runNotificationAdapter->sendNotification();
              }
           }

           $obj = KpiFrequency::getByYear(date('Y'));

           return [
               'message'=>'Notifications sent',
            //    'data'=>$usr,
               'interval'=>$obj
           ];

      }


}