<?php 

namespace App\Adapters;

interface KpiNotifyUserAdapter{
  
     function getUser();
     function setUser($user);
     function getRequest();
     function setRequest($request);
     function sendNotification();

}