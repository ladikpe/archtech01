<?php 

namespace App\Adapters;

use App\Adapters\KpiNotifyUserAdapter;

interface AddKpiUserDepartmentAdapter{
        
    function rateByMe();
    function rateByLineManager();
    
    //user
    function setUser($user);
    function getUser();

    function setNotification(KpiNotifyUserAdapter $kpiNotifyUserAdapter);

    //kpi-department
    function setKpiDepartment($kpiDepartment);
    function getKpiDepartment();

    //
    function setKpiFrequencyIntervalId($kpiFrequencyIntervalId);
    function getKpiFrequencyIntervalId();

    function setRequest($request);
    function getRequest();

    function setKpiUserDepartment($kpiUserDepartment);
    function getKpiUserDepartment();

    // function 
    // KpiUserDepartmentAction $kpiUserDepartmentAction,
    // KpiUserDepartment $kpiUserDepartment,
    // User $user,
    // KpiDepartment $kpiDepartment,
    // kpiFrequencyInterval $kpiFrequencyIntervalId,
    // Request $request

}