<?php 

namespace App\Adapters;

interface FetchKpiUserOrganizationAdapter{
    function fetch();
    function setUser($user);
    function setKpiOrganization($kpiOrganization);
    function setKpiIntervalId($kpiIntervalId);
}