<?php 
namespace App\Adapters;

use App\Adapters\KpiNotifyUserAdapter;

interface RunNotificationAdapter{
  
     function getProximityValue();
     function isProximityNear();
     function getUsers();
     function setNotification(KpiNotifyUserAdapter $kpiNotifyUserAdapter);
     function sendNotification();

}