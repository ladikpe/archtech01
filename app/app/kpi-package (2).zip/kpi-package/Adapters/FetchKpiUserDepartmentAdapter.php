<?php
namespace App\Adapters;

interface FetchKpiUserDepartmentAdapter{
 
    function fetch();
    function setUser($user);
    function setKpiDepartment($kpiDepartment);
    function setKpiIntervalId($kpiIntervalId);
    //$user, $kpiDepartment, $kpiFrequencyIntervalId
}