<?php 

namespace App\Adapters;

use App\Adapters\KpiNotifyUserAdapter;

interface AddKpiUserOrganizationAdapter{
        
    function rateByMe();
    function rateByLineManager();
    
    //user
    function setUser($user);
    function getUser();

    //kpi-department
    function setKpiOrganization($kpiOrganization);
    function getKpiOrganization();

    function setNotification(KpiNotifyUserAdapter $kpiNotifyUserAdapter);

    //
    function setKpiFrequencyIntervalId($kpiFrequencyIntervalId);
    function getKpiFrequencyIntervalId();

    function setRequest($request);
    function getRequest();

    function setKpiUserOrganization($kpiUserOrganization);
    function getKpiUserOrganization();

    // function 
    // KpiUserDepartmentAction $kpiUserDepartmentAction,
    // KpiUserDepartment $kpiUserDepartment,
    // User $user,
    // KpiDepartment $kpiDepartment,
    // kpiFrequencyInterval $kpiFrequencyIntervalId,
    // Request $request

}