<?php 
namespace App\Adapters;

interface SendGlobalNotificationPort{
   
     function getSubject();
     function getMessage();
    //  function getEmailTo();
     function getEmailCopy();
    //  function send(); 
     function getUsers();

}