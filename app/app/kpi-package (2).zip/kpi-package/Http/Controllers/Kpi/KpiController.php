<?php

namespace App\Http\Controllers\Kpi;

use App\User;
use App\job_dep;

use App\Kpi\KpiFrequency;
use App\Kpi\KpiDepartment;


use App\Actions\CrudAction;
use App\Actions\UserAction;
use App\Kpi\KpiOrganization;
use Illuminate\Http\Request;
use App\Actions\JobDepAction;
use App\Kpi\KpiUserDepartment;

use App\Actions\KpiScoreAction;

use App\Kpi\KpiUserOrganization;

use App\Kpi\KpiFrequencyInterval;
use App\Actions\KpiFrequencyAction;

use App\Actions\KpiDepartmentAction;

use App\Http\Controllers\Controller;
use App\Actions\KpiOrganizationAction;
use App\Actions\RunNotificationAction;
use App\Adapters\KpiNotifyUserAdapter;
use App\Actions\KpiUserDepartmentAction;
use App\Actions\KpiUserOrganizationAction;
use App\Actions\KpiFrequencyIntervalAction;
use App\AdapterObjects\KpiNotifyUserObject;
use App\Adapters\AddKpiUserDepartmentAdapter;
use App\AdapterObjects\KpiNotifyLineManagerObject;
use App\AdapterObjects\RunNotificationAdapterObject;
use App\Actions\Notifications\MailToLineManagerAction;
use App\AdapterObjects\AddKpiUserDepartmentAdapterObject;
use App\AdapterObjects\AddKpiUserOrganizationAdapterObject;
use App\AdapterObjects\FetchKpiUserDepartmentAdapterObject;
use App\AdapterObjects\FetchKpiUserOrganizationAdapterObject;
use App\AdapterObjects\SendGlobalNotificationAdapter;
use App\JobAva;
use App\Services\SendGlobalNotificationService;

class KpiController extends Controller
{
    //




    function boot()
    {
        return view('kpi.boot');
    }

    function getUsers(
        UserAction $userAction,
        User $user,
        Request $request
    ) {
        $workdept_id = '';
        if ($request->has('workdept_id')) {
            $workdept_id = $request->workdept_id;
        }
        return $userAction->all($user, $workdept_id);
    }

    function getDepartments(

        JobAva $jobAva,
        JobDepAction $jobDepAction
    ) {
        return $jobDepAction->all($jobAva);
    }


    function getKpiDepartments(
        KpiDepartment $kpiDepartment,
        KpiDepartmentAction $kpiDepartmentAction,
        $dept_id,
        $kpiFrequency,
        kpiUserDepartment $kpiUserDepartment,
        KpiUserDepartmentAction $kpiUserDepartmentAction,
        Request $request
    ) {
        return $kpiDepartmentAction->all($kpiDepartment, $dept_id, $kpiFrequency, $kpiUserDepartment, $kpiUserDepartmentAction, $request);
    }


    ///KPI DEPARTMENTS SECTION


    function storeKpiDepartment(
        Request $request,
        KpiDepartment $kpiDepartment,
        KpiDepartmentAction $kpiDepartmentAction
    ) {

        return $kpiDepartmentAction->store($kpiDepartment, $request);
    }


    function updateKpiDepartment(
        Request $request,
        KpiDepartment $kpiDepartment,
        KpiDepartmentAction $kpiDepartmentAction
    ) {
        return $kpiDepartmentAction->update($kpiDepartment, $request);
    }

    function destroyKpiDepartment(
        KpiDepartment $kpiDepartment,
        KpiDepartmentAction $kpiDepartmentAction
    ) {
        return $kpiDepartmentAction->delete($kpiDepartment);
    }



    ////KPI ORGANIZATION

    function getKpiOrganization(
        KpiOrganization $kpiOrganization,
        KpiOrganizationAction $kpiOrganizationAction,
        $dept_id,
        $kpiFrequency,
        KpiUserOrganization $kpiUserOrganization,
        KpiUserOrganizationAction $kpiUserOrganizationAction,
        Request $request
    ) {
        //getUserValue
        return $kpiOrganizationAction->all($kpiOrganization, $dept_id, $kpiFrequency, $kpiUserOrganization, $kpiUserOrganizationAction, $request);
    }

    function storeKpiOrganization(
        Request $request,
        KpiOrganization $kpiOrganization,
        KpiOrganizationAction $kpiOrganizationAction
    ) {

        return $kpiOrganizationAction->store($kpiOrganization, $request);
    }


    function updateKpiOrganization(
        Request $request,
        KpiOrganization $kpiOrganization,
        KpiOrganizationAction $kpiOrganizationAction
    ) {
        return $kpiOrganizationAction->update($kpiOrganization, $request);
    }

    function destroyKpiOrganization(
        KpiOrganization $kpiOrganization,
        KpiOrganizationAction $kpiOrganizationAction
    ) {
        return $kpiOrganizationAction->delete($kpiOrganization);
    }



    ////KPI USER DEPARTMENTS//////////
    //KpiUserDepartmentAction
    function getUserKpiDepartment(
        User $user,
        KpiDepartment $kpiDepartment,
        KpiUserDepartmentAction $kpiUserDepartmentAction,
        kpiFrequencyInterval $kpiFrequencyIntervalId,
        FetchKpiUserDepartmentAdapterObject $fetchKpiUserDepartmentAdapterObject
    ) {

        $fetchKpiUserDepartmentAdapterObject->setUser($user);
        $fetchKpiUserDepartmentAdapterObject->setKpiDepartment($kpiDepartment);
        $fetchKpiUserDepartmentAdapterObject->setKpiIntervalId($kpiFrequencyIntervalId);

        return $kpiUserDepartmentAction->fetch($fetchKpiUserDepartmentAdapterObject);

        // return $kpiUserDepartmentAction->all(
        //     $user,
        //     $kpiDepartment,
        //     $kpiFrequencyIntervalId
        // );

    }


    ////KPI USER DEPARTMENTS//////////
    //KpiUserDepartmentAction
    function getUserKpiOrganization(
        User $user,
        KpiOrganization $kpiOrganization,
        kpiFrequencyInterval $kpiFrequencyIntervalId,
        KpiUserOrganizationAction $kpiUserOrganizationAction,
        FetchKpiUserOrganizationAdapterObject $fetchKpiUserOrganizationAdapterObject
    ) {


        $fetchKpiUserOrganizationAdapterObject->setUser($user);
        $fetchKpiUserOrganizationAdapterObject->setKpiOrganization($kpiOrganization);
        $fetchKpiUserOrganizationAdapterObject->setKpiIntervalId($kpiFrequencyIntervalId);

        // return $kpiFrequencyIntervalId;

        return $kpiUserOrganizationAction->fetch($fetchKpiUserOrganizationAdapterObject);

        // return $kpiUserOrganizationAction->all(
        //     $user,
        //     $kpiOrganization,
        //     $kpiFrequencyIntervalId
        // );
    }
    //getUserKpiOrganization


    function rateKpiDepartmentByMe(
        User $user,
        KpiDepartment $kpiDepartment,
        kpiFrequencyInterval $kpiFrequencyIntervalId,
        Request $request,
        KpiUserDepartment $kpiUserDepartment,
        KpiUserDepartmentAction $kpiUserDepartmentAction,
        AddKpiUserDepartmentAdapterObject $addKpiUserDepartmentAdapterObject,
        KpiNotifyLineManagerObject $kpiNotifyLineManagerObject
    ) {

        //user , kpiDepartment , frequencyId
        $addKpiUserDepartmentAdapterObject->setRequest($request);
        $addKpiUserDepartmentAdapterObject->setUser($user);
        $addKpiUserDepartmentAdapterObject->setKpiDepartment($kpiDepartment);
        $addKpiUserDepartmentAdapterObject->setKpiUserDepartment($kpiUserDepartment);
        $addKpiUserDepartmentAdapterObject->setKpiFrequencyIntervalId($kpiFrequencyIntervalId); //($request);

        //setup notification here
        $kpiNotifyLineManagerObject->setUser($user->line_manager());
        $kpiNotifyLineManagerObject->setRequest($request);



        $addKpiUserDepartmentAdapterObject->setNotification($kpiNotifyLineManagerObject);

        // return $user->line_manager();
        //line_manager

        return $kpiUserDepartmentAction->rateByMe($addKpiUserDepartmentAdapterObject);

        // return $kpiUserDepartmentAction->rateByMe(
        //     $kpiUserDepartment,
        //     $user,
        //     $kpiDepartment,
        //     $kpiFrequencyIntervalId,
        //     $request
        // );
    }

    function rateKpiDepartmentByThirdParty(
        User $user,
        KpiDepartment $kpiDepartment,
        kpiFrequencyInterval $kpiFrequencyIntervalId,
        Request $request,
        KpiUserDepartment $kpiUserDepartment,
        KpiUserDepartmentAction $kpiUserDepartmentAction,
        AddKpiUserDepartmentAdapterObject $addKpiUserDepartmentAdapterObject
    ) {

        $addKpiUserDepartmentAdapterObject->setRequest($request);
        $addKpiUserDepartmentAdapterObject->setUser($user);
        $addKpiUserDepartmentAdapterObject->setKpiDepartment($kpiDepartment);
        $addKpiUserDepartmentAdapterObject->setKpiUserDepartment($kpiUserDepartment);
        $addKpiUserDepartmentAdapterObject->setKpiFrequencyIntervalId($kpiFrequencyIntervalId); //($request);

        return $kpiUserDepartmentAction->rateByLineManager($addKpiUserDepartmentAdapterObject);
        // return $kpiUserDepartmentAction->rateByLineManager($kpiUserDepartment, $user, $kpiDepartment, $kpiFrequencyIntervalId, $request);
    }



    //Organization
    function rateKpiOrganizationByMe(
        User $user,
        KpiOrganization $kpiOrganization,
        kpiFrequencyInterval $kpiFrequencyIntervalId,
        Request $request,
        KpiUserOrganization $kpiUserOrganization,
        KpiUserOrganizationAction $kpiUserOrganizationAction,
        AddKpiUserOrganizationAdapterObject $addKpiUserOrganizationAdapterObject,
        KpiNotifyLineManagerObject $kpiNotifyLineManagerObject
    ) {

        $addKpiUserOrganizationAdapterObject->setRequest($request);
        $addKpiUserOrganizationAdapterObject->setUser($user);
        $addKpiUserOrganizationAdapterObject->setKpiFrequencyIntervalId($kpiFrequencyIntervalId);
        $addKpiUserOrganizationAdapterObject->setKpiUserOrganization($kpiUserOrganization);
        $addKpiUserOrganizationAdapterObject->setKpiOrganization($kpiOrganization);

        //setup notification here
        $kpiNotifyLineManagerObject->setUser($user->line_manager());
        $kpiNotifyLineManagerObject->setRequest($request);

        $addKpiUserOrganizationAdapterObject->setNotification($kpiNotifyLineManagerObject);

        return $kpiUserOrganizationAction->rateByMe($addKpiUserOrganizationAdapterObject);

        // return $kpiUserOrganizationAction->rateByMe(
        //     $kpiUserOrganization,
        //     $user,
        //     $kpiOrganization,
        //     $kpiFrequencyIntervalId,
        //     $request
        // );
    }

    function rateKpiOrganizationByThirdParty(
        User $user,
        KpiOrganization $kpiOrganization,
        kpiFrequencyInterval $kpiFrequencyIntervalId,
        Request $request,
        KpiUserOrganization $kpiUserOrganization,
        KpiUserOrganizationAction $kpiUserOrganizationAction,
        AddKpiUserOrganizationAdapterObject $addKpiUserOrganizationAdapterObject
    ) {

        $addKpiUserOrganizationAdapterObject->setRequest($request);
        $addKpiUserOrganizationAdapterObject->setUser($user);
        $addKpiUserOrganizationAdapterObject->setKpiFrequencyIntervalId($kpiFrequencyIntervalId);
        $addKpiUserOrganizationAdapterObject->setKpiUserOrganization($kpiUserOrganization);
        $addKpiUserOrganizationAdapterObject->setKpiOrganization($kpiOrganization);

        return $kpiUserOrganizationAction->rateByLineManager($addKpiUserOrganizationAdapterObject);

        //$kpiUserOrganization, $user, $kpiOrganization, $kpiFrequencyIntervalId, $request
    }


    ///KPI-Frequency

    function storeKpiFrequency(
        CrudAction $crudAction,
        KpiFrequencyAction $kpiFrequencyAction,
        KpiFrequency $kpiFrequency,
        Request $request
    ) {

        return $kpiFrequencyAction->store([
            'model' => $kpiFrequency,
            'request' => $request,
            'crudAction' => $crudAction
        ]);
    }

    function updateKpiFrequency(
        CrudAction $crudAction,
        KpiFrequencyAction $kpiFrequencyAction,
        KpiFrequency $kpiFrequency,
        Request $request
    ) {
        return $kpiFrequencyAction->update([
            'model' => $kpiFrequency,
            'request' => $request,
            'crudAction' => $crudAction
        ]);
    }

    function deleteKpiFrequency(
        CrudAction $crudAction,
        KpiFrequency $kpiFrequency,
        KpiFrequencyAction $kpiFrequencyAction
    ) {
        return $kpiFrequencyAction->delete([
            'model' => $kpiFrequency,
            'crudAction' => $crudAction
        ]);
    }

    function allKpiFrequency(
        CrudAction $crudAction,
        KpiFrequency $kpiFrequency,
        KpiFrequencyAction $kpiFrequencyAction
    ) {
        return $kpiFrequencyAction->all([
            'model' => $kpiFrequency,
            'crudAction' => $crudAction
        ]);
    }

    function currentKpiFrequency(
        KpiFrequencyAction $kpiFrequencyAction,
        KpiFrequency $kpiFrequency,
        $year
    ) {
        return $kpiFrequencyAction->getCurrentKpiFrequency([
            'model' => $kpiFrequency,
            'year' => $year
        ]);
    }

    function KpiFrequencyCurrentInterval(
        KpiFrequencyAction $kpiFrequencyAction,
        KpiFrequency $kpiFrequency
    ) {
        // print_r($kpiFrequency->kpi_frequency_intervals);
        return $kpiFrequencyAction->getCurrentInterval([
            'model' => $kpiFrequency,
            'date' => date('Y-m-d') //'2019-07-29'
        ]);
    }

    function kpiFrequencyGetByYear(
        KpiFrequencyAction $kpiFrequencyAction,
        KpiFrequency $kpiFrequency,
        $year
    ) {
        return $kpiFrequencyAction->getByYear([
            'year' => $year,
            'model' => $kpiFrequency
        ]);
    }


    function kpiFrequencyGetByCurrentYear(
        KpiFrequencyAction $kpiFrequencyAction,
        KpiFrequency $kpiFrequency
    ) {
        return $kpiFrequencyAction->getByYear([
            'year' => date('Y'),
            'model' => $kpiFrequency
        ]);
    }


    //Kpi Frequency Interval
    function storeKpiFrequencyInterval(
        CrudAction $crudAction,
        KpiFrequencyIntervalAction $kpiFrequencyIntervalAction,
        KpiFrequencyInterval $kpiFrequencyInterval,
        Request $request
    ) {
        return $kpiFrequencyIntervalAction->store([
            'request' => $request,
            'model' => $kpiFrequencyInterval,
            'crudAction' => $crudAction
        ]);
    }

    function updateKpiFrequencyInterval(
        CrudAction $crudAction,
        KpiFrequencyIntervalAction $kpiFrequencyIntervalAction,
        KpiFrequencyInterval $kpiFrequencyInterval,
        Request $request
    ) {
        return $kpiFrequencyIntervalAction->update([
            'request' => $request,
            'model' => $kpiFrequencyInterval,
            'crudAction' => $crudAction
        ]);
    }

    function deleteKpiFrequencyInterval(
        CrudAction $crudAction,
        KpiFrequencyIntervalAction $kpiFrequencyIntervalAction,
        KpiFrequencyInterval $kpiFrequencyInterval
    ) {
        return $kpiFrequencyIntervalAction->delete([
            'model' => $kpiFrequencyInterval,
            'crudAction' => $crudAction
        ]);
    }

    function allKpiFrequencyInterval(
        CrudAction $crudAction,
        KpiFrequencyIntervalAction $kpiFrequencyIntervalAction,
        KpiFrequency $kpiFrequency
    ) {
        return $kpiFrequencyIntervalAction->all([
            'kpiFrequency' => $kpiFrequency,
            'crudAction' => $crudAction
        ]);
    }

    //rateKpiOrganizationByMe

    function getUserValueDepartment(
        $kpiFrequencyIntervalId,
        $group_id,
        $user_id,
        KpiUserDepartment $kpiUserDepartment,
        KpiUserDepartmentAction $kpiUserDepartmentAction
    ) {
        // $kpiFrequencyIntervalId = $config['kpiFrequencyIntervalId'];
        // $group_id = $config['group_id'];
        // $user_id = $config['user_id'];
        // $kpiFrequencyInterval = $config['kpiFrequencyInterval'];
        return $kpiUserDepartmentAction->getUserValue([
            'kpiFrequencyIntervalId' => $kpiFrequencyIntervalId,
            'group_id' => $group_id,
            'user_id' => $user_id,
            'kpiUserDepartment' => $kpiUserDepartment
        ]);
    }



    function getUserValueOrganization(
        $kpiFrequencyIntervalId,
        $group_id,
        $user_id,
        KpiUserOrganization $kpiUserOrganization,
        KpiUserOrganizationAction $kpiUserOrganizationAction
    ) {
        // $kpiFrequencyIntervalId = $config['kpiFrequencyIntervalId'];
        // $group_id = $config['group_id'];
        // $user_id = $config['user_id'];
        // $kpiFrequencyInterval = $config['kpiFrequencyInterval'];
        return $kpiUserOrganizationAction->getUserValue([
            'kpiFrequencyIntervalId' => $kpiFrequencyIntervalId,
            'group_id' => $group_id,
            'user_id' => $user_id,
            'kpiUserOrganization' => $kpiUserOrganization
        ]);
    }


    ////Kpi Scoring
    function getUserKpiScore(
        $field,
        $user_id,
        $kpi_frequency_interval_id,
        KpiScoreAction $kpiScoreAction
    ) {

        $response = $kpiScoreAction->getScore([
            'field' => $field,
            'user_id' => $user_id,
            'kpi_frequency_interval_id' => $kpi_frequency_interval_id
        ]);

        return $response;
    }

    function notifyLineManager(
        User $user,
        Request $request,
        MailToLineManagerAction $mailToLineManagerAction,
        KpiNotifyLineManagerObject $kpiNotifyLineManagerObject
    ) {
        $kpiNotifyLineManagerObject->setRequest($request);
        $kpiNotifyLineManagerObject->setUser($user);
        return $mailToLineManagerAction->send($kpiNotifyLineManagerObject);
    }

    function sendProximityNotification(
        RunNotificationAction $runNotificationAction,
        RunNotificationAdapterObject $runNotificationAdapterObject,
        KpiNotifyUserObject $kpiNotifyUserObject
    ) {
        return $runNotificationAction->run($runNotificationAdapterObject, $kpiNotifyUserObject);
    }



    ///////////////
    function sendGlobalNotification(Request $request)
    {
        //SendGlobalNotificationAdapter
        $sendGlobalNotificationAdapter = new SendGlobalNotificationAdapter($request);
        $sendGlobalNotificationService = new SendGlobalNotificationService($sendGlobalNotificationAdapter);
        return $sendGlobalNotificationService->send();
    }





    // getUserValue
}
